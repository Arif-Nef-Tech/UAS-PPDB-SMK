<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class FrontModel extends CI_Model {

    

}

/* End of file FrontModel.php */
