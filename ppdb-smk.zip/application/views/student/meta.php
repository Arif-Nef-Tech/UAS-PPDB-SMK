<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Dashboard Pendaftar</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="<?= base_url('assets/templates/student/');?>css/bootstrap.min.css" rel="stylesheet">
<link href="<?= base_url('assets/templates/student/');?>css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="<?= base_url('assets/templates/student/');?>css/font-awesome.css" rel="stylesheet">
<link href="<?= base_url('assets/templates/student/');?>css/style.css" rel="stylesheet">
<link href="<?= base_url('assets/templates/student/');?>css/pages/dashboard.css" rel="stylesheet">
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <style>
	.menuku li {
		display: inline-block;
		width: auto;
		height: 30px;
		font-weight: bold;
		margin-right: 5px;
	}
	.menuku {
		/* background-color: red; */
		padding: 2px;
		margin-bottom: 5px;
		border-radius: 6px;
	}
</style>
</head>
<body>