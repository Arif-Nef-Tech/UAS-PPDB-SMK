        <!-- footer start -->
        <footer class="bg-dark footer">
            <div class="container-fluid"> 
                <!-- end row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="float-left pull-none">
                            <p class="text-white-50">2024 &copy; Penerimaan Peserta Didik
                                <?= $sekolah['nama_sekolah'] ;?>
                            </p>
                        </div>
                        <div class="float-right pull-none">
                            
                        </div>
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- container-fluid -->
        </footer>
        <!-- footer end -->
        <!-- Back to top -->    
        <a href="#" class="back-to-top" id="back-to-top"> 
            <i class="mdi mdi-chevron-up"> 
            </i> 
        </a>