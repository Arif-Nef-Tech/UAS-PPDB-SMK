
<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1"> 
        <title><?= $title ;?></title>
        <link rel="icon" type="image/ico" href="<?= base_url('assets/templates/front/');?>img/logo.png">
        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
        <!-- Styles -->
        <link href="<?= base_url('assets/templates/front/');?>css/styleLanding.css?v=1.1" rel="stylesheet">
        <link href="<?= base_url('assets/templates/front/');?>css/materialdesignicons.min.css" rel="stylesheet">
        <link href="<?= base_url('assets/templates/front/');?>css/bootstrap.min.css" rel="stylesheet">
        <style>
            .my {
                border-bottom: 1px solid #aaa;
            }
            #launcher {
                display: none !important;
            }
        </style>
            </head>
    <body>
    